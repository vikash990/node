var http=require('http');
var uc=require('upper-case')
var port=8080;


http.createServer(function(req,res){
    
    
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write(uc.upperCase("hello world "))
    return res.end();
    


}).listen(port,function(){
    console.log(`server is listening ${port} port`)
})