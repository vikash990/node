var fs=require('fs')

var readSomething =fs.createReadStream('./dem.txt')

readSomething.on('open',function(){
    console.log("the file is open")
})